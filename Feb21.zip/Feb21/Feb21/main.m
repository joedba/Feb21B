//
//  main.m
//  Feb21
//
//  Created by Joe Gabela on 2/19/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Feb21AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Feb21AppDelegate class]));
    }
}
